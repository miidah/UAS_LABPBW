Di My shoppee website bisa kita tambah post tentang apa yang kita jual, bisa edit dan juga hapus.
